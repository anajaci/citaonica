app_key = "my5NeKaeuNH9tpWy2ow2kVf9t"
app_secret = "713FpTfdHKVpbLHD4HkEU5c141ywVuG2c9cer7UfrwtlugoZzr"
oauth_token = "870312122655412225-8tzZEuAYV4sAlzb6rVagPxXxiqAw0Ev"
oauth_token_secret = "Is84MRhvSkefw6FKHw66MSgY6S5HecA7oAsX7skAcEjis"
